package com.example.sunlife_boot_security;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.persistence.autoconfigure.EntityScan;
import org.springframework.context.annotation.Bean;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.security.crypto.password.PasswordEncoder;

import com.entity.AppUser;
import com.repo.SecurityRepo;

@SpringBootApplication(scanBasePackages = "com")
@EnableJpaRepositories("com.repo")
@EntityScan("com.entity")

public class SunlifeBootSecurityApplication {

	public static void main(String[] args) {
		SpringApplication.run(SunlifeBootSecurityApplication.class, args);
	}
	/*
	 * @Bean CommandLineRunner loadData(SecurityRepo repo,PasswordEncoder encoder) {
	 * return args -> { repo.save(new AppUser("admin", encoder.encode("admin123"),
	 * "ADMIN")); repo.save(new AppUser("trainer", encoder.encode("trainer123"),
	 * "TRAINER")); repo.save(new AppUser("student", encoder.encode("student123"),
	 * "STUDENT")); }; }
	 */

}
