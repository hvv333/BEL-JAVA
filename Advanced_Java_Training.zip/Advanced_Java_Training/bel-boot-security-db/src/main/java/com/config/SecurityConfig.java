package com.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
public class SecurityConfig {
	@Bean
	PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}

	@Bean
	public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception{
		http.csrf(csrf -> csrf.disable())
		.authorizeHttpRequests(auth -> 
		 auth.requestMatchers("/login", "/register").permitAll()
		.requestMatchers("/admin/**").hasRole("ADMIN")
		.requestMatchers("/student/**").hasRole("STUDENT")
		.requestMatchers("/trainer/**").hasAnyRole("TRAINER","ADMIN")
		.requestMatchers("/home").authenticated()
		.anyRequest().authenticated())
		.formLogin(login -> login.loginPage("/login").defaultSuccessUrl("/home",true).permitAll())
		.logout(logout -> logout.logoutUrl("/logout")
				.logoutSuccessUrl("/login?logout").permitAll())
		.exceptionHandling(ex -> ex.accessDeniedPage("/access-denied"))		
		.headers(headers -> headers.frameOptions(frame -> frame.disable()));
		return http.build();
		
	}

}
