package com.example.bel_spring_crud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.persistence.autoconfigure.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication(scanBasePackages = "com")
@EntityScan("com.policy.entity")
@EnableJpaRepositories("com.policy.repo")
public class BelSpringCrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(BelSpringCrudApplication.class, args);
	}

}
