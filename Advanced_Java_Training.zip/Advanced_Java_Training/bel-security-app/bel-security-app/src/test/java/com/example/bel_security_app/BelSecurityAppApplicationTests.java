package com.example.bel_security_app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BelSecurityAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
