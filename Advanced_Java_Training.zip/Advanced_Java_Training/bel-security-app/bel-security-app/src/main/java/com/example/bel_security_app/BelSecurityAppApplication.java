package com.example.bel_security_app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BelSecurityAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(BelSecurityAppApplication.class, args);
	}

}
