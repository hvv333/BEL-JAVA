package com.policy.service;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.policy.model.Policy;
import com.policy.model.PolicyStatus;
import com.policy.model.PolicyType;

public class PolicyServiceTest {
 
	private PolicyServiceImpl policyService;
	@BeforeEach
	void SetUp() {
		policyService = new PolicyServiceImpl();
	}
	
	@Test
	void ShouldCreatePolicy() {
		Policy policy = new Policy(101, "sumit", PolicyType.HEALTH_INSURANCE, PolicyStatus.RUNNING, 234.56);
		Policy result = policyService.createPolicy(policy);
		
		
		assertEquals("sumit", result.getPolicyHolderName());
		assertEquals(101, result.getPolicyId());
	}
	
	@Test
	void ShouldLoadPolicy() {
		Policy policy = new Policy(101, "sumit", PolicyType.HEALTH_INSURANCE, PolicyStatus.RUNNING, 234.56);
		Policy policy2 = new Policy(102, "hvv", PolicyType.HEALTH_INSURANCE, PolicyStatus.RUNNING, 234.56);
		policyService.createPolicy(policy);
        policyService.createPolicy(policy2);
        List<Policy> policies = policyService.loadPolicies();
          assertEquals(2, policies.size());
          
	}
}
