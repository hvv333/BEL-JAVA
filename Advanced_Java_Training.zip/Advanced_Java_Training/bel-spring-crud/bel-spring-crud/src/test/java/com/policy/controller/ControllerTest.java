
package com.policy.controller;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

 import com.policy.model.Policy;
import com.policy.model.PolicyStatus;
import com.policy.model.PolicyType;
import com.policy.service.PolicyService;

import tools.jackson.databind.ObjectMapper;

@ExtendWith(MockitoExtension.class)
class PolicyControllerTest {

    private MockMvc mockMvc;

    private ObjectMapper objectMapper;

    @Mock
    private PolicyService service;

    @InjectMocks
    private PolicyController policyController;

    @BeforeEach
    void setUp() {

        mockMvc = MockMvcBuilders
                .standaloneSetup(policyController)
                .build();

        objectMapper = new ObjectMapper();
    }


 
    @Test
    void shouldCreatePolicy() throws Exception {

		Policy policy= new Policy(101, "sumit", PolicyType.HEALTH_INSURANCE,PolicyStatus.RUNNING, 234.56);


        when(service.createPolicy(policy))
                .thenReturn(policy);

        mockMvc.perform(
                post("/policy/addpolicy")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(policy))
        )
        .andExpect(status().isCreated())
        .andExpect(jsonPath("$.policyId").value(101))
        .andExpect(jsonPath("$.policyHolderName").value("sumit"))
        .andExpect(jsonPath("$.policyStatus").value("RUNNING"))
        .andExpect(jsonPath("$.policyType").value("HEALTH_INSURANCE"))
        .andExpect(jsonPath("$.premiumAmount").value(234.56));
    }


  
    @Test
    void shouldGetPolicyById() throws Exception {

		Policy policy= new Policy(101, "sumit", PolicyType.HEALTH_INSURANCE,PolicyStatus.RUNNING, 234.56);

        when(service.getPolicyByID(101))
                .thenReturn(policy);

        mockMvc.perform(
                get("/policy/loadpolicy/101")
        )
        .andExpect(status().isOk())
        .andExpect(jsonPath("$.policyId").value(101))
        .andExpect(jsonPath("$.policyHolderName").value("sumit"))
        .andExpect(jsonPath("$.policyStatus").value("RUNNING"))
        .andExpect(jsonPath("$.policyType").value("HEALTH_INSURANCE"))
        .andExpect(jsonPath("$.premiumAmount").value(234.56));
    



//    @Test
//    void shouldLoadAllPolicies() throws Exception {
//
//        Policy policy1 = new Policy();
//
//        policy1.setPolicyId(101);
//        policy1.setPolicyHolderName("Rahul");
//        policy1.setPolicyStatus("ACTIVE");
//        policy1.setPolicyType("LIFE");
//        policy1.setPremiumAmount(50000);
//
//
//        Policy policy2 = new Policy();
//
//        policy2.setPolicyId(102);
//        policy2.setPolicyHolderName("Amit");
//        policy2.setPolicyStatus("ACTIVE");
//        policy2.setPolicyType("HEALTH");
//        policy2.setPremiumAmount(75000);
//
//
//        List<Policy> policies = Arrays.asList(policy1, policy2);
//
//        when(service.loadPolicies())
//                .thenReturn(policies);
//
//
//        mockMvc.perform(
//                get("/policy/loadpolicies")
//        )
//        .andExpect(status().isOk())
//        .andExpect(jsonPath("$[0].policyId").value(101))
//        .andExpect(jsonPath("$[0].policyHolderName").value("Rahul"))
//        .andExpect(jsonPath("$[1].policyId").value(102))
//        .andExpect(jsonPath("$[1].policyHolderName").value("Amit"));
//    }
}}

