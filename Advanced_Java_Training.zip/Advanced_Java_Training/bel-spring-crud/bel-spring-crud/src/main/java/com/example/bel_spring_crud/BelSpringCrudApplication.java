package com.example.bel_spring_crud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages = "com")
public class BelSpringCrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(BelSpringCrudApplication.class, args);
	}

}
