package com.policy.service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

import org.springframework.stereotype.Service;

import com.policy.exceptions.PolicyNotFoundException;
import com.policy.model.Policy;
import com.policy.model.PolicyStatus;

@Service
public class PolicyServiceImpl implements PolicyService {
	
	private List<Policy> policies = new ArrayList<Policy>();

	@Override
	public Policy createPolicy(Policy policy) {
		boolean exists = policies.stream().anyMatch(p -> p.getPolicyId() == policy.getPolicyId());
		if(exists) {
			throw new IllegalArgumentException("Policy already exists with ID "+ policy.getPolicyId());
		}
		policies.add(policy);
		return policy;
	}

	@Override
	public List<Policy> loadPolicies() {
		// TODO Auto-generated method stub
		return policies;
	}

	@Override
	public Policy getPolicyByID(int pId) {	
		return policies.stream().filter(policy -> policy.getPolicyId() == pId).findFirst()
				.orElseThrow(() -> new PolicyNotFoundException("Policy Not Found with ID : " + pId));
	}

	@Override
	public void deletePolicyByID(int pId) {
		Policy policy = getPolicyByID(pId);
		policies.remove(policy);
		
	}

	@Override
	public Policy updatePolicyByID(int pId, Policy policy) {
		Policy policyPool = getPolicyByID(pId);
		policyPool.setPolicyHolderName(policy.getPolicyHolderName());
		policyPool.setPolicyStatus(policy.getPolicyStatus());
		policyPool.setPolicyType(policy.getPolicyType());
		policyPool.setPremiumAmount(policy.getPremiumAmount());
		return policyPool;
	}

	@Override
	public List<Policy> getRunningPolicy() {
		return policies.stream().filter(f -> f.getPolicyStatus() == PolicyStatus.RUNNING).toList();
					
	}

}
