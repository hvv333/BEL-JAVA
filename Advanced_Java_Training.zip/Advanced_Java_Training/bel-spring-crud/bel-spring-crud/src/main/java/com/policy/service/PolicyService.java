package com.policy.service;

import java.util.List;
import java.util.stream.Stream;

import com.policy.exceptions.PolicyNotFoundException;
import com.policy.model.Policy;
import com.policy.model.PolicyStatus;

public interface PolicyService {
public Policy createPolicy(Policy policy);
public List<Policy> loadPolicies();
public Policy getPolicyByID(int pId);
public void deletePolicyByID(int pId);
public Policy updatePolicyByID(int pId, Policy policy);
public List<Policy> getRunningPolicy();
}
