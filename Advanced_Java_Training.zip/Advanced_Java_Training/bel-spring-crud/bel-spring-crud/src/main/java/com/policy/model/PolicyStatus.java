package com.policy.model;

public enum PolicyStatus {
	
	EXPIRED, CANCELLED, RUNNING

}
