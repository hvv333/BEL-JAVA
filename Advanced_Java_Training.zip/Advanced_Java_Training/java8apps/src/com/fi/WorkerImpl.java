package com.fi;

public class WorkerImpl {
	
	public static void execute(WorkerInterface worker) {
		worker.doSomeWork();
	}
	
	public static void main(String[] args) {
		WorkerInterface interface1 = new WorkerInterface() {
			
			
			
			
		
		};
		
	}


}
