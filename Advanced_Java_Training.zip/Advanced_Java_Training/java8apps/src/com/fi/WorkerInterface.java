package com.fi;

public class WorkerInterface {
	
	public void doSomeWork() {
		
	}
	

}
