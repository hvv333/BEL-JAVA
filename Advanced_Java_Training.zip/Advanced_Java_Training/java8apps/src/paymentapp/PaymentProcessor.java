package paymentapp;

public class PaymentProcessor {

    public static String process(Payment payment) {
        return switch (payment) {
            
            case UpiPayment(String upiID, double amt) when upiID == null || upiID.isBlank() || upiID == "" || amt <= 0 -> 
                "Invalid payment";
            case UpiPayment(String upiID, double amt) when amt > 50000 -> 
                "Manual approval required";
            case UpiPayment(String upiID, double amt) when amt > 10000 -> 
                "Processing High-Value UPI Payment";
            case UpiPayment(String upiID, double amt) -> 
                "Processing Standard UPI Payment";

            
            case CardPayment(String card, double amt) when card == null || card.isBlank() || amt <= 0 -> 
                "Invalid payment";
            case CardPayment(String card, double amt) when amt > 50000 -> 
                "Manual approval required";
            case CardPayment(String card, double amt) when amt > 10000 -> 
                "Processing High-Value Card Payment\nAdditional verification required";
            case CardPayment(String card, double amt) -> 
                "Processing Card Payment " + card + " Amount " + amt;

            
            case WalletPayment w when w.getWalletID() == null || w.getWalletID().isBlank() || w.getAmount() <= 0 -> 
                "Invalid payment";
            case WalletPayment w when w.getAmount() > 50000 -> 
                "Manual approval required";
            case WalletPayment w when w.getAmount() > 5000 -> 
                "Processing Wallet Payment " + w.getWalletID() + " Amount " + w.getAmount() + "\nWallet limit verification required";
            case WalletPayment w -> 
                "Processing Wallet Payment " + w.getWalletID() + " Amount " + w.getAmount();
                
            case NetBankingPayment(String bankName, double amt)->
                 "Processing Standard Net Banking Payment: " + bankName;
                 
        };
    }
}