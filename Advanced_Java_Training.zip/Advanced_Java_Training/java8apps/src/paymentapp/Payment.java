package paymentapp;

public sealed interface Payment permits UpiPayment, WalletPayment , CardPayment, NetBankingPayment {

}
