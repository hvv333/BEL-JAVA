package paymentapp;

public record NetBankingPayment(String bankName, double amount) implements Payment {

}
