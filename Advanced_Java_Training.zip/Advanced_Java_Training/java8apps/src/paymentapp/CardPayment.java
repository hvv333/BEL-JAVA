package paymentapp;

public record CardPayment(String cardNumber, double amount) implements Payment{

}
