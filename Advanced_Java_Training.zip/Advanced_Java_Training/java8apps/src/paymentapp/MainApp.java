package paymentapp;

public class MainApp {
	
	public static void main(String[] args) {
		
		Payment p1 = new UpiPayment("harsh@ybl" , 15000);
		System.out.println(PaymentProcessor.process(p1));
		
		Payment p2 = new CardPayment("150016001400" , 15000);
		System.out.println(PaymentProcessor.process(p2));
		
		Payment p3 = new WalletPayment("142365" , 15000);
		System.out.println(PaymentProcessor.process(p3));
		
		Payment p4 = new NetBankingPayment("HDFC" , 15000);
		System.out.println(PaymentProcessor.process(p4));
		
		

	}
	
	

}
