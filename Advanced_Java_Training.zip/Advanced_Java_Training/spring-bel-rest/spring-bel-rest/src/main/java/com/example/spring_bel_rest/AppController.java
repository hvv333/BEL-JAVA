package com.example.spring_bel_rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/bel")
public class AppController {
	
	@Autowired
	private AppService appservice;
	
		
	@GetMapping("/greet")
	public String sayWelcome() {
		return "Welcome to BEL Banglore";
	}
	
	@GetMapping("/login")
	public String loginapp() {
		return appservice.sayWelcome();
	}

}
