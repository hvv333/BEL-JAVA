package com.example.spring_bel_rest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBelRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBelRestApplication.class, args);
	}

}
