package com.example.spring_bel_rest;

import org.springframework.stereotype.Service;

@Service
public class AppService {
	
	public String sayWelcome() {
		return "Welcome to Login Page";
	}

}
