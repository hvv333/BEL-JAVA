package com.example.spring_bel_rest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBelRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
