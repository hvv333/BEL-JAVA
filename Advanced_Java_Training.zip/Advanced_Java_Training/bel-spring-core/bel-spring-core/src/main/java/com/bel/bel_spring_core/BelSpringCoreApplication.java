package com.bel.bel_spring_core;

import java.math.BigDecimal;
import java.util.List;
import java.util.concurrent.Future;

import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.config.BookingConfig;
import com.executer.BookingTaskExecuter;
import com.model.Flight;
import com.service.BookingService;

@SpringBootApplication
public class BelSpringCoreApplication {

	public static void main(String[] args) {
		ApplicationContext context = new AnnotationConfigApplicationContext(BookingConfig.class);
		
		BookingService flightser = context.getBean(BookingService.class);
		BookingTaskExecuter taskExecuter = context.getBean(BookingTaskExecuter.class);	
		System.out.println("==========Running APP============");
		Future<List<Flight>> delhimumbai = taskExecuter.searchFlight("Delhi", "Mumbai");
		
		System.out.println("Delhi-Mumbai Search");
		try {
		delhimumbai.get().forEach(System.out ::println);
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}
	
		Future<List<Flight>> delhiblr = taskExecuter.searchFlight("Delhi", "Bangalore");
		
		System.out.println("Delhi-BLR Search");
		try {
		delhiblr.get().forEach(System.out ::println);
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}
		

		Future<List<Flight>> mumbaichennai = taskExecuter.searchFlight("Mumbai", "Chennai");
		
		System.out.println("Mumbai-Chennai Search");
		try {
		mumbaichennai.get().forEach(System.out ::println);
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}

		Future<List<Flight>> delhimumbai2 = taskExecuter.searchFlight("Delhi", "Mumbai");
		
		System.out.println("Delhi-Mumbai Search Again");
		try {
		delhimumbai2.get().forEach(System.out ::println);
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}
			
		Future<String> calculaterevenue  = taskExecuter.calculateRevenue();
		System.out.println("Calculating Revenue");
		try {
		calculaterevenue.toString();
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}
		

		
		taskExecuter.shutdown();
		
		
	}
	
	
	
	

}
