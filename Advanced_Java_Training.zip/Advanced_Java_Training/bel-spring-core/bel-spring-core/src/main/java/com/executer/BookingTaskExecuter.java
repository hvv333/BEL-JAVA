package com.executer;

import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import org.springframework.stereotype.Component;

import com.model.Flight;
import com.service.BookingService;

@Component
public class BookingTaskExecuter {
	private BookingService bookingService;
	private ExecutorService executorService= Executors.newFixedThreadPool(3);
	public BookingTaskExecuter(BookingService bookingService) {
		super();
		this.bookingService = bookingService;
		System.out.println("Executer Created");
	}
	public Future<List<Flight>> searchFlight(String origin,String destination){
		Callable<List<Flight>>task= () -> {
			System.out.println(
					Thread.currentThread().getName()
					+ " Searching...!"
					+ origin
					+ "-->"
					+destination);
			return bookingService.searchFlight(origin,destination);
			
		};
		return executorService.submit(task);
	}

	
	public Future<Flight>findFlight(String flightno){
		Callable<Flight>task= () -> {
			System.out.println(
					Thread.currentThread().getName()
					+ " finding flight...!"
					+ flightno
					);
			return bookingService.getFlight(flightno).orElse(null);
			
		};
		return executorService.submit(task);
	}
 
	public Future<String>calculateRevenue(){
		Callable<String>task= () -> {
			System.out.println(
					Thread.currentThread().getName()
					+ " Calculating Revenue...!"
					
					);
			return bookingService.calculateRevenue().toString();
			
		};
		return executorService.submit(task);
	}
 
	public void shutdown() {
		executorService.shutdown();
		System.out.println("Application Stopped..!");
	}
	
	
}
