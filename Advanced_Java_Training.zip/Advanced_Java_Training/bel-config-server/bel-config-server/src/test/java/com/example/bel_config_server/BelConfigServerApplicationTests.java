package com.example.bel_config_server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BelConfigServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
