package com.policy.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.policy.entity.Employee;
import com.policy.exceptions.PolicyNotFoundException;
import com.policy.repo.AppRepo;

@Service
public class EmpServiceImpl implements EmpService {
	
	@Autowired
	private AppRepo repo;
	
	private List<Employee> employees = new ArrayList<Employee>();

	@Override
	public Employee createEmployee(Employee emp) {
		boolean exists = employees.stream().anyMatch(p -> p.getEmpId() == emp.getEmpId());
		if(exists) {
			throw new IllegalArgumentException("Policy already exists with ID "+ emp.getEmpId());
		}
		
		repo.save(emp);
		return emp;
	}

	@Override
	public List<Employee> loadEmployees() {
		return (List<Employee>) repo.findAll();
	}


}
