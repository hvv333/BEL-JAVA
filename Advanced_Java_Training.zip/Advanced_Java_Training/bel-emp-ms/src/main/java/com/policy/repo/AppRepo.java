package com.policy.repo;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.policy.entity.Employee;


import jakarta.transaction.Transactional;

@Repository
public interface AppRepo extends CrudRepository<Employee, Integer> {
	
}
