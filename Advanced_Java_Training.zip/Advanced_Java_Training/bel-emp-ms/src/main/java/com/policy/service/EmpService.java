package com.policy.service;

import java.util.List;
import java.util.stream.Stream;

import org.jspecify.annotations.Nullable;

import com.policy.entity.Employee;
import com.policy.exceptions.PolicyNotFoundException;

public interface EmpService {
public Employee createEmployee(Employee emp);
public List<Employee> loadEmployees();

}
