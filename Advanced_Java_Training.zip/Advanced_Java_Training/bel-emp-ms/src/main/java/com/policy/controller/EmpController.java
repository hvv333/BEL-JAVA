package com.policy.controller;

import java.util.List;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.policy.entity.Employee;
import com.policy.service.EmpService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/emp")
public class EmpController {
	
	@Autowired
	private EmpService service;
	
	@PostMapping("/addemployee")
	public ResponseEntity<Employee> createEmployee(@Valid @RequestBody Employee emp){
		Employee savedData= service.createEmployee(emp);
		return ResponseEntity.status(HttpStatus.CREATED).body(savedData);
		
	}
	
	@GetMapping("/loademployees")
	public ResponseEntity<List<Employee>> loadEmployees(){
		return ResponseEntity.ok(service.loadEmployees());
	}
	

}