package com.example.bel_spring_crud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BelSpringCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
