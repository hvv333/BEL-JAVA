package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.model.Policy;
import com.service.PolicyClientService;

import jakarta.validation.Valid;

 
@RequestMapping("/client")
@RestController
public class ClientController {
	@Autowired
	private PolicyClientService service;
	
	@GetMapping("/loadpolicies")
	public ResponseEntity<List<Policy>> loadPolicies(){	
		return ResponseEntity.ok(service.loadAllPolicies());		
	}
	
	@PostMapping("/addpolicy")
	public ResponseEntity<Policy> createPolicy(@Valid @RequestBody Policy policy){
		Policy savedData= service.createPolicy(policy);
		return ResponseEntity.status(HttpStatus.CREATED).body(savedData);
		
	}

}