package com.model;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class Policy {
	
	@NotNull(message = "Policy ID can't be blank")
	private int policyId;
	@NotNull(message = "Policyholder name can't be blank")
	private String policyHolderName;
	private PolicyType policyType;
	private PolicyStatus policyStatus;
	private double premiumAmount;
	

}
