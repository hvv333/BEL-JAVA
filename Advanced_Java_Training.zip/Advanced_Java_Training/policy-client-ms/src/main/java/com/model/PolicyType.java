package com.model;

public enum PolicyType {
	
	HEALTH_INSURANCE, LIFE_INSURANCE, CAR_INSURANCE

}
