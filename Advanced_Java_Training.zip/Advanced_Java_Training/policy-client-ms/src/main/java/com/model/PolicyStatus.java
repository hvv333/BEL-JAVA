package com.model;

public enum PolicyStatus {
	
	EXPIRED, CANCELLED, RUNNING

}
