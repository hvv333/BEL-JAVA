package com.example.bel_api_gateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BelApiGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
