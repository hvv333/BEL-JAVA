package com.policy.service;

import java.util.List;
import java.util.stream.Stream;

import org.jspecify.annotations.Nullable;

import com.policy.entity.Policy;
import com.policy.entity.PolicyStatus;
import com.policy.exceptions.PolicyNotFoundException;

public interface PolicyService {
public Policy createPolicy(Policy policy);
public List<Policy> loadPolicies();
public Policy getPolicyByID(int pId);
public void deletePolicyByID(int pId);
public Policy updatePolicyByID(int pId, Policy policy);
public List<Policy> loadPolicyByStatus(PolicyStatus status);
}
