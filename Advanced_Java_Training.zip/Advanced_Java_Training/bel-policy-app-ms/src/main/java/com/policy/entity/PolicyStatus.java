package com.policy.entity;

public enum PolicyStatus {
	
	EXPIRED, CANCELLED, RUNNING

}
