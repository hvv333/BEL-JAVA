package com.policy.repo;

import java.util.List;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.policy.entity.Policy;
import com.policy.entity.PolicyStatus;
import com.policy.entity.PolicyType;

import jakarta.transaction.Transactional;

@Repository
public interface AppRepo extends CrudRepository<Policy, Integer> {
	
	@Modifying
	@Transactional
	@Query("""
			UPDATE Policy p
			SET p.policyHolderName= :name,
			p.policyType= :type,
			p.policyStatus= :status,
			p.premiumAmount= :premium
			where p.policyId = :id
					
			""")
			
	int updatePolicy(
			@Param("id") int id,
			@Param("name") String name,
			@Param("type") PolicyType type,
			@Param("status") PolicyStatus status,
			@Param("premium") double premium);
	
	
	

	@Query("""
			SELECT  p from Policy p 
			WHERE p.policyStatus = :status			
			""")
	
	List<Policy> findbyStatus(	
			@Param("status") PolicyStatus status);

}
