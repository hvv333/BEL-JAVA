package com.policy.controller;

import java.util.List;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.policy.entity.Policy;
import com.policy.entity.PolicyStatus;
import com.policy.service.PolicyService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/policy")
public class PolicyController {
	
	@Autowired
	private PolicyService service;
	
	@PostMapping("/addpolicy")
	public ResponseEntity<Policy> createPolicy(@Valid @RequestBody Policy policy){
		Policy savedData= service.createPolicy(policy);
		return ResponseEntity.status(HttpStatus.CREATED).body(savedData);
		
	}
	
	@GetMapping("/loadpolicies")
	public ResponseEntity<List<Policy>> loadPolicy(){
		return ResponseEntity.ok(service.loadPolicies());
	}
	
	@GetMapping("/loadpolicy/{pId}")
	public ResponseEntity<Policy> loadPolicy(@PathVariable int pId){
		return ResponseEntity.ok(service.getPolicyByID(pId));
	}
	
	@GetMapping("/policybystatus/{pStatus}")
	public ResponseEntity<List<Policy>> loadPolicyByStatus(@PathVariable PolicyStatus status){
		return ResponseEntity.ok(service.loadPolicyByStatus(status));
	}
		
	@DeleteMapping("/deletePolicy/{pId}")
	public ResponseEntity<String> deletePolicy(@PathVariable int pId) {
		service.deletePolicyByID(pId);
		return ResponseEntity.ok("Policy Deleted");
	}
	
	@PutMapping("/updatePolicy/{pId}")
	public ResponseEntity<Policy> updatePolicy(@PathVariable int pId, @RequestBody Policy policy) {
		Policy updatedData = service.updatePolicyByID(pId, policy);
		return ResponseEntity.status(HttpStatus.CREATED).body(updatedData);
	}
	

}