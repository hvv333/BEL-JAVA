package com.policy.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
public class Policy {
	
	@Id
	private int policyId;
	@NotNull(message = "Policyholder name can't be blank")
	private String policyHolderName;
	private PolicyType policyType;
	private PolicyStatus policyStatus;
	private double premiumAmount;
	

}
