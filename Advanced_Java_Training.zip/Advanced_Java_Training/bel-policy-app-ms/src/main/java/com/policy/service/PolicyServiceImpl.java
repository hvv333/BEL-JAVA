package com.policy.service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.policy.entity.Policy;
import com.policy.entity.PolicyStatus;
import com.policy.exceptions.PolicyNotFoundException;
import com.policy.repo.AppRepo;

@Service
public class PolicyServiceImpl implements PolicyService {
	
	@Autowired
	private AppRepo repo;
	
	private List<Policy> policies = new ArrayList<Policy>();

	@Override
	public Policy createPolicy(Policy policy) {
		boolean exists = policies.stream().anyMatch(p -> p.getPolicyId() == policy.getPolicyId());
		if(exists) {
			throw new IllegalArgumentException("Policy already exists with ID "+ policy.getPolicyId());
		}
		
		repo.save(policy);
		return policy;
	}

	@Override
	public List<Policy> loadPolicies() {
		return (List<Policy>) repo.findAll();
	}

	@Override
	public Policy getPolicyByID(int pId) {	
		return repo.findById(pId).orElseThrow(() -> new PolicyNotFoundException(""));
	}

	@Override
	public void deletePolicyByID(int pId) {
		Policy policy = getPolicyByID(pId);
		repo.delete(policy);
		
	}

	@Override
	public Policy updatePolicyByID(int pId, Policy policy) {
		int rowsUpdated = repo.updatePolicy(pId, policy.getPolicyHolderName(), policy.getPolicyType(), policy.getPolicyStatus(), policy.getPremiumAmount());
		if(rowsUpdated==0) {
			throw new PolicyNotFoundException("");
		}
		return getPolicyByID(pId);
	}

	@Override
	public List<Policy> loadPolicyByStatus(PolicyStatus status) {
		return repo.findbyStatus(status);
	}


}
