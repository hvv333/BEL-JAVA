package com.bel.bel_spring_core;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BelSpringCoreApplicationTests {

	@Test
	void contextLoads() {
	}

}
