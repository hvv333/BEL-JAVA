package com.model;

public record UpiPayment(String upiId, double amount) implements Payment {

}
