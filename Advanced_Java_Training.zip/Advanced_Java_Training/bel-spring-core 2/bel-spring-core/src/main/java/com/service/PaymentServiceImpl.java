package com.service;

import org.springframework.stereotype.Service;

import com.model.CardPayment;
import com.model.Payment;

import ch.qos.logback.classic.pattern.MaskedKeyValuePairConverter;
@Service
public class PaymentServiceImpl implements PaymentService {
	
	@Override
	public void processPayment(Payment payment) {
		
		System.out.println("\n============PAYMENT============");
		System.out.println("Payment Type : " + payment.paymentType());
		System.out.println("Amount $ : " + payment.amount());
		
		if (payment instanceof CardPayment card) {
			System.out.println("Card : " + maskCard(card.cardNumber()));
		}
		System.out.println("Payment Successful.......");
	}
		
		private String maskCard(String cardNumber) {
			if (cardNumber.length() <= 4) {
				return cardNumber;
			}
			
			return "XXXX-XXXX-XXXX-"+cardNumber.substring(cardNumber.length()-4);
		}


		
	}

