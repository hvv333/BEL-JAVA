package com.model;

public sealed interface Payment permits UpiPayment, WalletPayment , CardPayment, NetBankingPayment {
	
	double amount();
	
	default String paymentType() {
		return getClass().getSimpleName();
		
	}
       
}
