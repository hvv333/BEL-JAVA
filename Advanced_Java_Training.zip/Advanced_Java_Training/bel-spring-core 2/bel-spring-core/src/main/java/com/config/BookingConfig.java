package com.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.repo.FlightRepoImpl;
import com.repo.FlightRepoImpl2;
import com.service.BookingServiceImpl;

@Configuration
@ComponentScan("com")
public class BookingConfig {
	
//	@Bean
//	public FlightRepoImpl flightRepoImpl() {
//		return new FlightRepoImpl();
//	}
//	
//	@Bean
//	public FlightRepoImpl2 flightRepoImpl2() {
//		return new FlightRepoImpl2();
//	}
	
//	@Bean
//	public BookingServiceImpl bookingServiceImpl(FlightRepoImpl flightRepoImpl) {
//		return new BookingServiceImpl(flightRepoImpl);
//	}
//
//	@Bean
//	public BookingServiceImpl bookingServiceImpl(FlightRepoImpl2 flightRepoImpl2) {
//		return new BookingServiceImpl(flightRepoImpl2);
//	}

}
