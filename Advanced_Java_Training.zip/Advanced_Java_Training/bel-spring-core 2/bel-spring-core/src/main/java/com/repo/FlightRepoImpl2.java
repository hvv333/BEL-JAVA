package com.repo;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.model.Flight;

import com.model.Passengers;


public class FlightRepoImpl2 implements FlightRepo {
	
	public List<Flight> findAll(){
		return new ArrayList<>(List.of(
				
				new Flight("SJ101", "Delhi", "Mumbai", LocalDateTime.now().plusHours(5), BigDecimal.valueOf(5500),
						 List.of(new Passengers("Amar", "amar@mail.com"),
							new Passengers("Sumit", "sumit@mail.com"))),
					
					new Flight("SJ102", "Delhi", "Bangalore", LocalDateTime.now().plusHours(3), BigDecimal.valueOf(6500),
							 List.of(new Passengers("Amar", "amar@mail.com"))),
					new Flight("SJ103", "Mumbai", "Chennai", LocalDateTime.now().plusHours(6), BigDecimal.valueOf(4800),
							 List.of()),
					new Flight("SJ104", "Delhi", "Mumbai", LocalDateTime.now().plusHours(2), BigDecimal.valueOf(6000),
							 List.of(new Passengers("Harish", "harish@mail.com")
				
				
				))
				
				));
	}

}
