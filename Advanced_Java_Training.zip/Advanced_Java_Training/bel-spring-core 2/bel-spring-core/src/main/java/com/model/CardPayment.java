package com.model;

public record CardPayment(double amount, String cardNumber) implements Payment{

	

}
