package com.model;

public record NetBankingPayment(String bankName, double amount) implements Payment {

}
