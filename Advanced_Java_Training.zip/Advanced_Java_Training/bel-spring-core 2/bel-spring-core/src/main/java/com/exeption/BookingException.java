package com.exeption;

public class BookingException extends Exception{

	public BookingException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}
	