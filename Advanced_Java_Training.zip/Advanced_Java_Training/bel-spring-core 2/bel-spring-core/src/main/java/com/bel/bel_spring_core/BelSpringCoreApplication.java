package com.bel.bel_spring_core;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.config.BookingConfig;
import com.exeption.BookingException;
import com.model.CardPayment;
import com.model.Passengers;
import com.model.Payment;
import com.service.BookingService;
import com.service.BookingServiceImpl;
import com.service.PaymentService;

@SpringBootApplication
public class BelSpringCoreApplication {

	public static void main(String[] args) {
		ApplicationContext context = new AnnotationConfigApplicationContext(BookingConfig.class);
		
		BookingService bookingServiceImpl = context.getBean(BookingService.class);
		PaymentService paymentService = context.getBean(PaymentService.class);
		Payment payment = new CardPayment(4800, "8908980878529876");
		
		Passengers passengers = new Passengers("Amit", "Amit@mail.com");
		try {
			bookingServiceImpl.bookPassenger("AI103", passengers, payment );
		} catch (BookingException e) {
			System.out.println(e.getMessage());
		}

		
	}

}
