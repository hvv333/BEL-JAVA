package com.model;

public final class WalletPayment implements Payment {
	
	private final String walletID;
	private final double amount;
	
	public WalletPayment(String walletID, double amount) {
		super();
		this.walletID = walletID;
		this.amount = amount;
	}
	
	
	public String getWalletID() {
		return walletID;
	}
	public double getAmount() {
		return amount;
	}


	@Override
	public double amount() {
		// TODO Auto-generated method stub
		return amount;
	}

	
	

}
