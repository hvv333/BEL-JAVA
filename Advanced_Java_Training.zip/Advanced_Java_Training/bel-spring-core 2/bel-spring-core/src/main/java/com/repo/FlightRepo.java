package com.repo;

import java.util.ArrayList;
import java.util.List;

import com.model.Flight;

public interface FlightRepo {
	public List<Flight> findAll();

	

}
