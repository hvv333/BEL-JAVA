package com.model;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import com.model.Passengers;

public record Flight(
		
		 String flightNumber,
		 String origin,
		 String destination,
		 LocalDateTime departureTime,
		 BigDecimal price,
		 List<Passengers> passengers) {
		
		public Flight{
			if(passengers == null) {
				throw new NullPointerException("Passengers must not be null");
			}
			
			var copy = new ArrayList<>(passengers);
			passengers = copy;
		}
		
		public Flight(
				 String flightNumber,
				 String origin,
				 String destination,
				 LocalDateTime departuretime,
				 BigDecimal price) {
			this(flightNumber, origin, destination, departuretime, price , List.of());		
		}

		@Override
		public String toString() {
			return String.format("%s (%s -> %s) %sPrice: %s",
					flightNumber, origin, destination, departureTime, price); 
		}
		
		public void addPassenger(Passengers p) {
			passengers.add(p);
		}
		public boolean removePassengersByEmail(String email) {
			return passengers.removeIf(p -> p.email().equalsIgnoreCase(email));	}


		}