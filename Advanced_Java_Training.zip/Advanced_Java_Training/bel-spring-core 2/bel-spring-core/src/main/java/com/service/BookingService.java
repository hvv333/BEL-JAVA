package com.service;

import com.exeption.BookingException;
import com.model.Passengers;
import com.model.Payment;

public interface BookingService {
	
	public void bookPassenger(String fno, Passengers passengers, Payment payment)throws BookingException;

}
