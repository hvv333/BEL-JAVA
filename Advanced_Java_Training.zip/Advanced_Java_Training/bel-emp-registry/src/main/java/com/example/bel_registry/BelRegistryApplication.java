package com.example.bel_registry;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;

@SpringBootApplication
@EnableEurekaServer
public class BelRegistryApplication {

	public static void main(String[] args) {
		SpringApplication.run(BelRegistryApplication.class, args);
	}

}
