package com.example.bel_registry;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BelRegistryApplicationTests {

	@Test
	void contextLoads() {
	}

}
